That's where you could place playground plugins
