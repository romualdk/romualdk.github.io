If it gets too crowded in root folder you can divide these files further

example:

  states/
    Game.js
    Options.js
    Menu.js
    
  
