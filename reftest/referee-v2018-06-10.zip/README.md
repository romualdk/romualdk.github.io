TODO
Potwierdzenie kasowania. // DONE 2017-11-19
Informacja o tym czy mail się wysłał czy nie. // DONE 2017-11-19


Lista maili wysyłkowych - zaznaczenie, na które ma wysłać (+ zawsze na mail ligi).

Możliwość zapisania meczu do pliku.


Opcja notatek do meczu.
Opcja zaznaczenia gola z karnego.